/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bdwebrest.controller;

import com.bdwebrest.entity.Alunos;
import com.bdwebrest.service.AlunosService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author Natalia
 */
@RestController
@RequestMapping("/alunos")
public class AlunosController {
    
    @Autowired
    private AlunosService alunosservice;
    
    @GetMapping
    public List<Alunos> read (){
        return alunosservice.read();
    }
    
    @PostMapping
    public Alunos create(@RequestBody Alunos a){
       return alunosservice.create(a);
    }
    
    @PutMapping
    public Alunos update (@RequestBody Alunos a){
        return alunosservice.update(a);
    }
    
    @DeleteMapping
    public void delete(@RequestBody Alunos a){
        alunosservice.delete(a);
    }
    
    
    
    
}

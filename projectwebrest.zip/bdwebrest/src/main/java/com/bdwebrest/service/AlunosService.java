/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bdwebrest.service;

import com.bdwebrest.entity.Alunos;
import com.bdwebrest.repository.AlunosRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author Natalia
 */
@Service
public class AlunosService {
    
    @Autowired
    private AlunosRepository alunosrepository;
    
    public Alunos create (Alunos a){
        return alunosrepository.save(a);
    }
    
    public Alunos update (Alunos a ){
        return alunosrepository.save(a);
    }
    
    public List<Alunos> read(){
        return alunosrepository.findAll();
    }
    
    public void delete (Alunos a){
        alunosrepository.delete(a);
    }
    
}
